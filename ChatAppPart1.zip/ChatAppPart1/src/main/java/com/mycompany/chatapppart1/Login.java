/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapppart1;

/**
 *
 * @author Student
 */
public class Login {
    
    
    //user's information will be stored inside the variable
    String username;
    String password;
    String phoneNumber;
    
    // 1.CHECK USERNAME
    //Contaians underscore
    //No more than five characters
    public boolean checkUserName(String username ){
        return username.contains("_")&& username.length()<=5;
    }
    
    // 2. CHECK PASSWORD COMPLEXITY
    //At least 8 characters
    //At least 1 Capital letter
    //At least 1 number
    //At least 1 Specail Character
    public boolean checkPasswordComplexity(String password){
         
        boolean hasCapital = false;
        boolean hasNumber = false;
        boolean hasSpecial = false;
        
        for(int i = 0; i< password.length(); i++){
            char c = password.charAt(i);
            if (Character.isUpperCase(c)){
                hasCapital = true;
            }else if(Character.isDigit(c)){
                hasNumber = true;
            }else if(!Character.isLetterOrDigit(c)){
                hasSpecial = true;
            }
        }
        return password.length()>=8 && hasCapital && hasNumber && hasSpecial;
    }
    
    // 3.CHECK CELL PHONE NUMBER
    public boolean checkCellPhoneNumber(String phone){
        return phone.startsWith("+27") && phone.length() <= 12;
    }
    
    // 4. REGISTORE USER
    public String registerUser(String username,String password, String phoneNumber){
        
        if(!checkUserName(username)){  
            return "Username is not correctly formatted;please ensure that your username contains an underscore and is nomore than than five characters in length.";
        }
        
        if(!checkPasswordComplexity(password)){
            return"password is not correctly formatted;please ensure that the password contain at least eight characters,a capital letter,a number,and a specail character.";
        }
        
        if(!checkCellPhoneNumber(phoneNumber)){
            return"Cell phone number incorrectly formatted or does not contain international code.";
        }
        
        this.username=username;
        this.password=password;
        this.phoneNumber=phoneNumber;
        
        return"User registered successfully.";
    }
     
    // 5. LOGIN USER
    public boolean loginUser(String username, String pssword) {
        return this.username.equals(username)&& this.password.equals(password);
    }
    
    //6.RETURN LOGIN STATUS
    public String returnLoginStatus(boolean success){
        if(success){
            return "Welcome" + username + "it is grat to see you again.";
        }else{
            return"Username or password incorrect, please try again.";
        }
        }

    }