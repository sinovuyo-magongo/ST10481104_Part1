/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapppart1; //package name my differ depending on your NetBeans setup
import java.util.Scanner;

/**
 *
 * @author Student
 */
public class Main {
    public static void main(String[]args){
        
        //Scanner allows the user to enter information
        Scanner input = new Scanner(System.in);
        
        //Create an object of the login class so we can call its methods
        Login login = new Login();
        
        //---REGISTRATION SECTION---
        System.out.print("=== USER REGISTRATION ===");
        
        System.out.print("Enter a username:");
        String username = input.nextLine();
        
        System.out.print("Enter a password: ");
        String password = input.nextLine();
        
        System.out.print("Enter your South African phone number (+27):");
        String phone = input.nextLine();
        
        // Call the registerUser method and the message it returns
        String response = login.registerUser(username, password, phone);
        
        //Show the registration message
        System.out.println(response);
        
        //---LOGIN SECTION---
        System.out.println("\n=== USER LOGIN ===");
        
        System.out.print("Enter your username: ");
        String loginUsername = input.nextLine();
        
        System.out.print("Enter your password: ");
        String loginPassword = input.nextLine();
        
        //Call loginUser to if details match the stored ones
        boolean loggedIn = login.loginUser(loginUsername, loginPassword);
        
        //Print out the correct lgin message
        String loginMessage =  login.returnLoginStatus(loggedIn);
        System.out.println(loginMessage);
    }
    
}
