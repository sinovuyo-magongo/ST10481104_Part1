/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import com.mycompany.mavenproject3.Login;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Student
 */
public class LoginTest {
   
    //Single Login instance used for all test
    Login login = new Login();
    //String testUsername = "Sinovuyo
    //Same username for all tests
   
    //---------------- USERNAME TESTS ----------------
    @Test
    public void testValidUsersname(){
        //this checks the username must have the underscores"_"
        //also checks the length of the username must not be more than 8 e.g ("Sinovuyo__")
        assertTrue(login.checkUserName("Sinovuyo_"));
    }
   
    @Test
    public void testInvalidUsername_NoUnderscore(){
        //check the username with no underscore
        //
        assertFalse(login.checkUserName("Sinovuyo!!!!!!!!"));
    }
    @Test
    public void testInvalidUsername_TooLong(){
        //reason why it is FALSE, the username is more than 8 characters
        //it was suppose to be 8(e.g"abong_")
        assertFalse(login.checkUserName("Sinovuyooo"));
    }
   
    //-------------PASSWORD TESTS--------------
    @Test
    public void testValidPassword(){
        //this check the password is correct
        //and the password must be atleast be 8 characters long
        assertTrue(login.CheckPassword("MAQO@n55!"));
    }
   
    @Test
    public void testInvalidPassword_NoNumber(){
        //check the password with no capital letter,no number and  no specail
        //it suppose to have the letter, number and special character
        assertFalse(login.checkPassword("MAQO@n!"));
    }
   
    @Test
    public void testInvalidPassword_NoCapitalLetter(){
        //the reason why its False the password is more than 8 character
        //it suppose have 8 characters long
        assertFalse(login.checkPassword("MAQHO&&@n55!"));
    }
   
    //--------------PHONE NUMBER TESTS--------------
    @Test
    public void testValidPhoneNumber(){
        //this checks that the number must start with +27
        //because its an internaltional code for South Africa
        assertFalse(login.checkPhoneNumber("+27749802214"));
    }
    @Test
    public void LoginTestinvalidPhoneNumber_MissingPus27() {
        //check the number if it has no international code
        //also if it has no more than 12 characters long
        assertFalse(login.checkPhoneNumber("0749802214"));
    }
    @Test
    public void InvalidPhoneNumber_MissingDigit() {
        //reason why it's False, the number has less than 8 digit
        //it was suppose to be 10 digit
        assertFalse(login.checkPhoneNumber("+277402214"));
    }

    private void assertTrue(String checkUserName) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void assertFalse(String checkUserName) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
