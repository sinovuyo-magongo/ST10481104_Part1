/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import com.mycompany.mavenproject3.Message;
import org.junit.jupiter.api.BeforeEach;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;

public class MessageTest {

    private Message msg1; // Test Case 1 data
    private Message msg2; // Test Case 2 data

    @BeforeEach
    public void setUp() {
        // Test Case 1: Valid message
        msg1 = new Message(1);
        msg1.setRecipient("+27718693002");
        msg1.setMessageText("Hi Mike, can you join us tonight");

        // Test Case 2: Invalid recipient, valid message
        msg2 = new Message(2);
        msg2.setRecipient("08575975889");
        msg2.setMessageText("Hi Keegan, did you receive the payment?");
    }

    // Test 1: Message length <= 250
    @Test
    public void testCheckMessageLength_Success() {
        assertEquals("Message ready to send.", msg1.checkMessageLength());
    }

    @Test
    public void testCheckMessageLength_Failure() {
        Message longMsg = new Message(3);
        String longText = "a".repeat(251);
        longMsg.setMessageText(longText);
        assertEquals("Message exceeds 250 characters by 1; please reduce the size.",
                     longMsg.checkMessageLength());
    }

    // Test 2: Recipient format
    @Test
    public void testCheckRecipientCell_Success() {
        assertEquals("Cell phone number successfully captured.",
                     msg1.checkRecipientCell());
    }

    @Test
    public void testCheckRecipientCell_Failure() {
        assertEquals("Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.",
                     msg2.checkRecipientCell());
    }

    // Test 3: Message Hash - Test Case 1 should return 00:0:HITONIGHT
    @Test
    public void testCreateMessageHash_TestCase1() {
        Message testMsg = new Message(0);
        testMsg.setMessageText("Hi Mike, can you join us tonight");
        // Manually set ID to 00... for test to match POE
        // In real test, you would mock or set ID. For POE, test the format:
        String hash = testMsg.createMessageHash();
        assertTrue(hash.endsWith(":HITONIGHT"));
    }

    // Test 4: Message ID is 10 digits
    @Test
    public void testCheckMessageID() {
        assertTrue(msg1.checkMessageID());
        assertEquals(10, msg1.getMessageID().length());
    }

    // Test 5: Loop through message hashes
    @Test
    public void testMessageHashesInLoop() {
        Message[] messages = {msg1, msg2};
        for (Message m : messages) {
            String hash = m.createMessageHash();
            assertNotNull(hash);
            assertTrue(hash.contains(":"));
        }
    }
}

