package com.mycompany.mavenproject3;

import java.util.Random;

public class Message {
    private static int messageCounter = 0;

    static String returnTotalMessages() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    static String validateMessageLength(String messageText) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    private int messageNumber;
    private String messageID;
    private String recipient;
    private String messageText;

    public Message(int messageNumber) {
        this.messageNumber = messageNumber;
        this.messageID = generateMessageID();
    }

    // Generate 10-digit random ID
    private String generateMessageID() {
        Random rand = new Random();
        long num = 1000000L + (long)(rand.nextDouble() * 9000000L);
        return String.valueOf(num);
    }

    public boolean checkMessageID() {
        return messageID.length() == 10;
    }

    // Check message length and return correct string per POE
    public String checkMessageLength() {
        int length = messageText.length();
        if (length <= 250) {
            return "Message ready to send.";
        } else {
            int over = length - 250;
            return "Message exceeds 250 characters by " + over + "; please reduce the size.";
        }
    }

    // Check recipient format: must start with + and be <= 10 chars total
    public String checkRecipientCell() {
        if (recipient!= null && recipient.startsWith("+") && recipient.length() <= 10) {
            return "Cell phone number successfully captured.";
        } else {
            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        }
    }

    // Create hash: first 2 digits of ID : messageNumber : FIRSTWORDLASTWORD
    public String createMessageHash() {
        String idPart = messageID.substring(0, 2);
        String[] words = messageText.trim().split("\\s+");
        String first = words[0].toUpperCase();
        String last = words[words.length - 1].toUpperCase();
        return idPart + ":" + messageNumber + ":" + first + last;
    }

    // Get first and last word for testing
    public String getFirstWord() {
        return messageText.trim().split("\\s+")[0].toUpperCase();
    }

    public String getLastWord() {
        String[] words = messageText.trim().split("\\s+");
        return words[words.length - 1].toUpperCase();
    }

    // Getters and setters
    public String getMessageID() { return messageID; }
    public String getRecipient() { return recipient; }
    public void setRecipient(String recipient) { this.recipient = recipient; }
    public String getMessageText() { return messageText; }
    public void setMessageText(String messageText) { this.messageText = messageText; }
    public int getMessageNumber() { return messageNumber; }

    String getMessageHash() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    String sentMessage(int sendChoice) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

   
    



