/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject3;

public class Login {

    private String username;
    private String password;
    private String firstName;
    private String lastName;
    private boolean loggedIn = false;

    // ---------- Registration ----------

    /**
     * Registers the user. Validates username and password format.
     * Returns a success or failure message.
     */
    public String registerUser(String firstName, String lastName, String username, String password) {
        this.firstName = firstName;
        this.lastName = lastName;

        String usernameResult = checkUserName(username);
        if (!usernameResult.equals("Username successfully captured.")) {
            return usernameResult;
        }

        String passwordResult = checkPasswordComplexity(password);
        if (!passwordResult.equals("Password successfully captured.")) {
            return passwordResult;
        }

        this.username = username;
        this.password = password;
        return "Registration successful! Welcome " + firstName + " " + lastName + ".";
    }

    /**
     * Username must contain an underscore and be no more than 5 characters.
     */
    public String checkUserName(String username) {
        if (username == null) {
            return "Username is not correctly formatted, please ensure that your username contains an " +
                   "underscore and is no more than 5 characters in length.";
        }
        if (!username.contains("_") || username.length() > 5) {
            return "Username is not correctly formatted, please ensure that your username contains an " +
                   "underscore and is no more than 5 characters in length.";
        }
        return "Username successfully captured.";
    }

    /**
     * Password must be at least 8 characters, contain a capital letter,
     * a number, and a special character.
     */
    public String checkPasswordComplexity(String password) {
        if (password == null || password.length() < 8) {
            return "Password is not correctly formatted; please ensure that the password contains at least " +
                   "8 characters, a capital letter, a number, and a special character.";
        }

        boolean hasCapital = false;
        boolean hasDigit = false;
        boolean hasSpecial = false;

        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) hasCapital = true;
            if (Character.isDigit(c)) hasDigit = true;
            if (!Character.isLetterOrDigit(c)) hasSpecial = true;
        }

        if (!hasCapital || !hasDigit || !hasSpecial) {
            return "Password is not correctly formatted; please ensure that the password contains at least " +
                   "8 characters, a capital letter, a number, and a special character.";
        }

        return "Password successfully captured.";
    }

    /**
     * Logs the user in. Returns a personalised success or failure message.
     */
    public String loginUser(String username, String password) {
        if (this.username == null || this.password == null) {
            return "Username or password incorrect, please try again.";
        }
        if (this.username.equals(username) && this.password.equals(password)) {
            loggedIn = true;
            return "Welcome " + firstName + " " + lastName + ", it is great to see you again.";
        }
        return "Username or password incorrect, please try again.";
    }

    public boolean isLoggedIn() {
        return loggedIn;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    String registerUser(String username, String password, String phoneNumber) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    String returnLoginStatus(String loginSuccess) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public String checkPhoneNumber(String string) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public String checkPassword(String maqOn55) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public String CheckPassword(String maqOn55) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
