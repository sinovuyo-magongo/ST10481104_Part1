/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject3;
import com.mycompany.mavenproject3.Message;
import java.util.Scanner;


public class MainApp {

    private static Object messege;

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        // ================= REGISTRATION =================
        Login login = new Login();

        System.out.println("===== USER REGISTRATION =====");
        System.out.print("Enter Username: ");
        String username = input.nextLine();

        System.out.print("Enter Password: ");
        String password = input.nextLine();

        System.out.print("Enter Phone Number: ");
        String phoneNumber = input.nextLine();

        String registrationMessage =
                login.registerUser(username, password, phoneNumber);
        System.out.println(registrationMessage);

        // Stop if registration failed
        if (!registrationMessage.equals("User registered successfully.")) {
            input.close();
            return;
        }

        // ================= LOGIN =================
        System.out.println("\n===== USER LOGIN =====");
        System.out.print("Enter Username: ");
        String loginUsername = input.nextLine();

        System.out.print("Enter Password: ");
        String loginPassword = input.nextLine();

        String loginSuccess =
                login.loginUser(loginUsername, loginPassword);
        String loginMessage =
                login.returnLoginStatus(loginSuccess);
        System.out.println(loginMessage);
        boolean LoginSuccess = false;

        // Stop if login failed
        if (!LoginSuccess) {
            input.close();
            return;
        } else {
        }

        // ================= QUICKCHAT APP =================
        System.out.println("\nWelcome to QuickChat.");

        // Ask how many messages the user wants to send
        System.out.print("\nHow many messages would you like to send? ");
        int maxMessages = 0;
        try {
            maxMessages = Integer.parseInt(input.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("Invalid number. Exiting.");
            input.close();
            return;
        }

        int menuChoice;

        // -------- Main menu loop --------
        do {
            System.out.println("\n--- QuickChat Menu ---");
            System.out.println("1) Send Messages");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Quit");
            System.out.print("Choose an option: ");

            String menuInput = input.nextLine().trim();
            try {
                menuChoice = Integer.parseInt(menuInput);
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
                menuChoice = 0;
                continue;
            }

            switch (menuChoice) {
                case 1 -> {
                    int messagesSentThisSession = 0;

                    while (messagesSentThisSession < maxMessages) {
                        System.out.println("\n--- Message "
                                + (messagesSentThisSession + 1)
                                + " of " + maxMessages + " ---");

                        // Recipient
                        System.out.print("Enter recipient cell number: ");
                        String recipient = input.nextLine().trim();

                        // Validate message text
                        String messageText = "";
                        while (true) {
                            System.out.print("Enter message (max 250 chars): ");
                            messageText = input.nextLine();

                            String lengthCheck =
                                    Message.validateMessageLength(messageText);
                            if (lengthCheck.equals("Message ready to send.")) {
                                System.out.println("Message sent");
                                break;
                            } else {
                                System.out.println("Please enter a message "
                                        + "of less than 250 characters.");
                            }
                        }
                        // Create the message


                        // Validate recipient
                        System.out.println(message.checkRecipientCell());

                        // Display auto-generated details
                        System.out.println("Message ID generated: "
                                + messege.getMessageID());
                        System.out.println("Message Hash: "
                                + messege.getMessageHash());

                        // Send / Store / Disregard menu
                        System.out.println("\nWhat would you like to do?");
                        System.out.println("1) Send Message");
                        System.out.println("2) Disregard Message");
                        System.out.println("3) Store Message to send later");
                        System.out.print("Choose: ");

                        int sendChoice = 0;
                        try {
                            sendChoice =
                                    Integer.parseInt(input.nextLine().trim());
                        } catch (NumberFormatException e) {
                            System.out.println("Invalid choice.");
                        }

                        String sendResult = messege.sentMessage(sendChoice);
                        System.out.println(sendResult);

                        // Show full message details after action
                        System.out.println("\n--- Message Details ---");
                        System.out.println("Message ID   : "
                                + messege.getMessageID());
                        System.out.println("Message Hash : "
                                + messege.getMessageHash());
                        System.out.println("Recipient    : "
                                + messege.getRecipient());
                        System.out.println("Message      : "
                                + messege.getMessageText());

                        messagesSentThisSession++;
                    }

                    // Show total after all messages entered
                    System.out.println("\nTotal messages sent: "
                            + Message.returnTotalMessages());
                }
                case 2 -> System.out.println("Coming Soon.");
                case 3 -> System.out.println("Goodbye!");

                default -> System.out.println("Invalid option. "
                            + "Please choose 1, 2, or 3.");
            }
            // ---------- OPTION 1: SEND MESSAGES ----------
            // ---------- OPTION 2: SHOW RECENTLY SENT ----------
            // ---------- OPTION 3: QUIT ----------
           
        } while (menuChoice != 3);

        input.close();
    }

}
